#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      dario
#
# Created:     21/11/2023
# Copyright:   (c) dario 2023
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from Trabajo.Entrega import entrega
from Trabajo.Pedido import PedidoC


class ClienteC():
    def __init__(self, nombre):
        self.nombre = nombre
        self.e = None

    def hacerEntrega(self,nombre, peso, vol,d,tMax):
        p = PedidoC(nombre, peso,vol)
        e = entrega(p,d,tMax)
        self.e = e
        return self.e

    def valorarEntrega(self, val):
        self.e.setVal(val)
