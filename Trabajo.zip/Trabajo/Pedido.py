
class PedidoC:
    def __init__(self, nombre, peso, vol):
        self.nombre = nombre
        self.peso = peso
        self.volumen = vol