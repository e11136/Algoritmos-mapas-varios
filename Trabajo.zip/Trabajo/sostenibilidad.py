from Graph import Grafo
from Mensajero import MensajeroC
from queue import Queue


def calculaLarga(lista):
    contador: int = 0
    for i in lista:
        if i:
            if contador < len(i):
                contador = len(i)
    return contador


class Sostenibilidad:
    def __init__(self, grafo_ciudad, mensajeros, entregas, entregas_pendientes):
        self.ciudad = grafo_ciudad
        self.mensajeros = mensajeros
        self.entregas = entregas
        self.entrega_pendiente = entregas_pendientes

    def asignarEntregas(self):
        self.entregas.sort(key=lambda entrega: entrega.tiempo_maximo_entrega)
        self.mensajeros.sort(key=lambda x: x.transporte.peso_maximo)
        for e in self.entregas:
            for m in self.mensajeros:
                if m.pesoTotal + e.pedido.peso <= m.transporte.peso_maximo:
                    s = self.ciudad.dijkstra(e.getdireccion(), m.mostrarEstado())
                    if int(s[1]) < m.transporte.limDist:
                        m.pesoTotal += e.pedido.peso
                        m.asignarEntrega(e)
                        break



    def realizarEntregasBFS(self):
        entregasMensajero = {}
        lista = {}
        distancia = {}
        while len(self.entrega_pendiente) > 0:
            for i,m in enumerate(self.mensajeros):
                entregasMensajero = m.getEntregasAsignadas()
                if entregasMensajero:
                    primeraEntrega = entregasMensajero[0]
                    lista[i], distancia[i] = self.ciudad.procura_BFS(m.estado, primeraEntrega.direccion_entrega)

            for i in range(0, len(lista)):
                for j in range(i+1, len(lista)):
                    if i in lista and j in lista:
                        lista1, lista2,x1, x2 = self.compruebaCaminosBFS(lista[i], lista[j], self.mensajeros[i], self.mensajeros[j])
                        lista[i] = lista1
                        lista[j] = lista2
                        distancia[i] = x1
                        distancia[j] = x2

            for i in range (len(self.mensajeros)):
                if i in distancia:
                    tiempo = distancia[i]/self.mensajeros[i].velocidad()
                    self.mensajeros[i].aumentaTiempo(tiempo)


            ##realizamos entregas
            for ite in range(0,calculaLarga(lista.values())):
                for indice ,m in enumerate(self.mensajeros):
                    if indice in lista.keys():
                        camino = lista[indice]
                        if len(camino) > ite:
                            entregasMensajero = m.getEntregasAsignadas()
                            for p in entregasMensajero:
                                if camino[ite] == p.direccion_entrega:
                                    p.setValoracion(5)
                                    m.realizar_entrega(p)
                                    self.entrega_pendiente.remove(p)
                                    print('mensajero ' + str(indice + 1) + ' entrego en ' + p.direccion_entrega)
                                    m.cambiarEstado(p.direccion_entrega)

            lista.clear()

        for m in self.mensajeros:
            print(f'El mensajero {m.id_mensajero} tiempo que se ha tardado es ' + str(m.tiempoTotal))


    def compruebaCaminosBFS(self, lista1, lista2, ms1, ms2):
        camino_final1 = lista1
        camino_final2 = lista2
        x, x1 = self.ciudad.procura_BFS(lista1[0], lista1[-1])
        x, x2 = self.ciudad.procura_BFS(lista2[0], lista1[-1])

        for i in lista1:
            for j in lista2:
                if i == j and (i != 'A' and j != 'A'):
                    x, km1 = self.ciudad.procura_BFS(lista1[0], i)
                    tiempoTotal1 = km1/ ms1.velocidad()
                    x, km2 = self.ciudad.procura_BFS(lista2[0], j)
                    tiempoTotal2 = km2/ ms2.velocidad()

                    if tiempoTotal1 == tiempoTotal2:
                        nuevo_grafo = self.ciudad.eliminar_nodo(i)
                        if lista1[-1] == i:
                            camino_final2, x2 = nuevo_grafo.procura_BFS(lista2[0], lista2[-1])
                        elif lista2[-1] == j:
                            camino_final1, x1 = nuevo_grafo.procura_BFS(lista1[0], lista1[-1])
                        elif ms1.transporte.peso_maximo < ms2.transporte.peso_maximo:
                            camino_final1.clear()
                            camino_final1, x1 = nuevo_grafo.procura_BFS(lista1[0], lista1[-1])
                        else:
                            camino_final2.clear()
                            camino_final2, x2 = nuevo_grafo.procura_BFS(lista2[0], lista2[-1])
                        break

        return camino_final1, camino_final2, x1, x2





    def realizarEntregasdijkstra(self):
        entregasMensajero = {}
        lista = {}
        distancia = {}
        while len(self.entrega_pendiente) > 0:
            for i,m in enumerate(self.mensajeros):
                entregasMensajero = m.getEntregasAsignadas()
                if entregasMensajero:
                    primeraEntrega = entregasMensajero[0]
                    lista[i], distancia[i] = self.ciudad.dijkstra(m.estado, primeraEntrega.direccion_entrega)
            ##print(lista)
            for i in range(0, len(lista)):
                for j in range(i+1, len(lista)):
                    if i in lista and j in lista:
                        lista1, lista2, x1, x2 = self.compruebaCaminosdijkstra(lista[i], lista[j], self.mensajeros[i], self.mensajeros[j])
                        lista[i] = lista1
                        lista[j] = lista2
                        distancia[i] = x1
                        distancia[j] = x2

            for i in range (len(self.mensajeros)):
                if i in distancia:
                    tiempo = distancia[i]/self.mensajeros[i].velocidad()
                    self.mensajeros[i].aumentaTiempo(tiempo)
                    ##print(tiempo)


            ##print(lista)
            ##realizamos entregas
            for ite in range(0,calculaLarga(lista.values())):
                for indice ,m in enumerate(self.mensajeros):
                    if indice in lista.keys():
                        camino = lista[indice]
                        if len(camino) > ite:
                            entregasMensajero = m.getEntregasAsignadas()
                            for p in entregasMensajero:
                                if camino[ite] == p.direccion_entrega:
                                    p.setValoracion(5)
                                    m.realizar_entrega(p)
                                    self.entrega_pendiente.remove(p)
                                    print('mensajero ' + str(indice + 1) + ' entrego en ' + p.direccion_entrega)
                                    m.cambiarEstado(p.direccion_entrega)
            lista.clear()
        for m in self.mensajeros:
            print(f'El mensajero {m.id_mensajero} tiempo que se ha tardado es ' + str(m.tiempoTotal))

    def compruebaCaminosdijkstra(self, lista1, lista2, ms1, ms2):
        camino_final1 = lista1
        camino_final2 = lista2
        x, x1 = self.ciudad.dijkstra(lista1[0], lista1[-1])
        x, x2 = self.ciudad.dijkstra(lista2[0], lista2[-1])
        for i in lista1:
            for j in lista2:
                if i == j and (i != 'A' and j != 'A'):
                    x, km1 = self.ciudad.dijkstra(lista1[0], i)
                    tiempoTotal1 = km1 / ms1.velocidad()
                    x, km2 = self.ciudad.dijkstra(lista2[0], j)
                    tiempoTotal2 = km2 / ms2.velocidad()

                    if tiempoTotal1 == tiempoTotal2:
                        nuevo_grafo = self.ciudad.eliminar_nodo(i)
                        if lista1[-1] == i:
                            camino_final2, x2 = nuevo_grafo.dijkstra(lista2[0], lista2[-1])
                        elif lista2[-1] == j:
                            camino_final1, x1 = nuevo_grafo.dijkstra(lista1[0], lista1[-1])
                        elif ms1.transporte.peso_maximo < ms2.transporte.peso_maximo:
                            camino_final1.clear()
                            camino_final1, x1 = nuevo_grafo.dijkstra(lista1[0], lista1[-1])
                        else:
                            camino_final2.clear()
                            camino_final2, x2 = nuevo_grafo.dijkstra(lista2[0], lista2[-1])
                        break

        return camino_final1, camino_final2, x1, x2


    def realizarEntregasGreedy(self):
        lista = {}
        distancia = {}
        while len(self.entrega_pendiente) > 0:
            for i,m in enumerate(self.mensajeros):
                entregasMensajero = m.getEntregasAsignadas()
                if entregasMensajero:
                    primeraEntrega = entregasMensajero[0]
                    lista[i], distancia[i] = self.ciudad.greedy(m.estado, primeraEntrega.direccion_entrega)
            ##print(lista)
            for i in range(0, len(lista)):
                for j in range(i+1, len(lista)):
                    if i in lista and j in lista:
                        lista1, lista2, x1, x2 = self.compruebaCaminosgreedy(lista[i], lista[j], self.mensajeros[i], self.mensajeros[j])
                        lista[i] = lista1
                        lista[j] = lista2
                        distancia[i] = x1
                        distancia[j] = x2

            for i in range (len(self.mensajeros)):
                if i in distancia:
                    tiempo = distancia[i]/self.mensajeros[i].velocidad()
                    self.mensajeros[i].aumentaTiempo(tiempo)
                    ##print(tiempo)


            ##print(lista)
            ##realizamos entregas
            for ite in range(0,calculaLarga(lista.values())):
                for indice ,m in enumerate(self.mensajeros):
                    if indice in lista.keys():
                        camino = lista[indice]
                        if len(camino) > ite:
                            entregasMensajero = m.getEntregasAsignadas()
                            for p in entregasMensajero:
                                if camino[ite] == p.direccion_entrega:
                                    p.setValoracion(5)
                                    m.realizar_entrega(p)
                                    self.entrega_pendiente.remove(p)
                                    print('mensajero ' + str(indice + 1) + ' entrego en ' + p.direccion_entrega)
                                    m.cambiarEstado(p.direccion_entrega)
            lista.clear()
        for m in self.mensajeros:
            print(f'El mensajero {m.id_mensajero} tiempo que se ha tardado es ' + str(m.tiempoTotal))

    def compruebaCaminosgreedy(self, lista1, lista2, ms1, ms2):
        camino_final1 = lista1
        camino_final2 = lista2
        x, x1 = self.ciudad.greedy(lista1[0], lista1[-1])
        x, x2 = self.ciudad.greedy(lista1[0], lista2[-1])
        for i in lista1:
            for j in lista2:
                if i == j and (i != 'A' and j != 'A'):
                    x, km1 = self.ciudad.greedy(lista1[0], i)
                    tiempoTotal1 = km1 / ms1.velocidad()
                    x, km2 = self.ciudad.greedy(lista2[0], j)
                    tiempoTotal2 = km2 / ms2.velocidad()

                    if tiempoTotal1 == tiempoTotal2:
                        nuevo_grafo = self.ciudad.eliminar_nodo(i)
                        if lista1[-1] == i:
                            camino_final2, x2 = nuevo_grafo.greedy(lista2[0], lista2[-1])
                        elif lista2[-1] == j:
                            camino_final1, x1 = nuevo_grafo.greedy(lista1[0], lista1[-1])
                        elif ms1.transporte.peso_maximo < ms2.transporte.peso_maximo:
                            camino_final1.clear()
                            camino_final1, x1 = nuevo_grafo.greedy(lista1[0], lista1[-1])
                        else:
                            camino_final2.clear()
                            camino_final2, x2 = nuevo_grafo.greedy(lista2[0], lista2[-1])
                        break

        return camino_final1, camino_final2, x1, x2

    def realizarEntregasA_estrella(self):
        lista = {}
        distancia = {}
        while len(self.entrega_pendiente) > 0:
            for i,m in enumerate(self.mensajeros):
                entregasMensajero = m.getEntregasAsignadas()
                if entregasMensajero:
                    primeraEntrega = entregasMensajero[0]
                    lista[i], distancia[i] = self.ciudad.procura_aStar(m.estado, primeraEntrega.direccion_entrega)
            ##print(lista)
            for i in range(0, len(lista)):
                for j in range(i+1, len(lista)):
                    if i in lista and j in lista:
                        lista1, lista2, x1, x2 = self.compruebaCaminosAEstrella(lista[i], lista[j], self.mensajeros[i], self.mensajeros[j])
                        lista[i] = lista1
                        lista[j] = lista2
                        distancia[i] = x1
                        distancia[j] = x2

            for i in range (len(self.mensajeros)):
                if i in distancia:
                    tiempo = distancia[i]/self.mensajeros[i].velocidad()
                    self.mensajeros[i].aumentaTiempo(tiempo)
                    ##print(tiempo)


            ##print(lista)
            ##realizamos entregas
            for ite in range(0,calculaLarga(lista.values())):
                for indice ,m in enumerate(self.mensajeros):
                    if indice in lista.keys():
                        camino = lista[indice]
                        if len(camino) > ite:
                            entregasMensajero = m.getEntregasAsignadas()
                            for p in entregasMensajero:
                                if camino[ite] == p.direccion_entrega:
                                    p.setValoracion(5)
                                    m.realizar_entrega(p)
                                    self.entrega_pendiente.remove(p)
                                    print('mensajero ' + str(indice + 1) + ' entrego en ' + p.direccion_entrega)
                                    m.cambiarEstado(p.direccion_entrega)
            lista.clear()
        for m in self.mensajeros:
            print(f'El mensajero {m.id_mensajero} tiempo que se ha tardado es ' + str(m.tiempoTotal))

    def compruebaCaminosAEstrella(self, lista1, lista2, ms1, ms2):
        camino_final1 = lista1
        camino_final2 = lista2
        x, x1 = self.ciudad.procura_aStar(lista1[0], lista1[-1])
        x, x2 = self.ciudad.procura_aStar(lista1[0], lista2[-1])
        for i in lista1:
            for j in lista2:
                if i == j and (i != 'A' and j != 'A'):
                    x, km1 = self.ciudad.procura_aStar(lista1[0], i)
                    tiempoTotal1 = km1 / ms1.velocidad()
                    x, km2 = self.ciudad.procura_aStar(lista2[0], j)
                    tiempoTotal2 = km2 / ms2.velocidad()

                    if tiempoTotal1 == tiempoTotal2:
                        nuevo_grafo = self.ciudad.eliminar_nodo(i)
                        if lista1[-1] == i:
                            camino_final2, x2 = nuevo_grafo.procura_aStar(lista2[0], lista2[-1])
                        elif lista2[-1] == j:
                            camino_final1, x1 = nuevo_grafo.procura_aStar(lista1[0], lista1[-1])
                        elif ms1.transporte.peso_maximo < ms2.transporte.peso_maximo:
                            camino_final1.clear()
                            camino_final1, x1 = nuevo_grafo.procura_aStar(lista1[0], lista1[-1])
                        else:
                            camino_final2.clear()
                            camino_final2, x2 = nuevo_grafo.procura_aStar(lista2[0], lista2[-1])
                        break

        return camino_final1, camino_final2, x1, x2





