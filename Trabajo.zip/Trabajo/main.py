from Trabajo.Cliente import ClienteC
from Trabajo.Graph import Grafo
from Trabajo.Mensajero import MensajeroC
from Trabajo.Transporte import Bicicleta, Moto, Coche
from Trabajo.sostenibilidad import Sostenibilidad


def main ():
    g = Grafo()
    g.add_edge("A","B",5)
    g.add_edge("A","D",8)
    g.add_edge("A","C",10)
    g.add_edge("B","F",64)
    g.add_edge("C","D",4)
    g.add_edge("C","E",40)
    g.add_edge("D","G",7)
    g.add_edge("E","H",30)
    g.add_edge("E","I",2)
    g.add_edge("G","H",20)
    g.add_edge("F","D",3)


    g.add_heuristica("A",0)
    g.add_heuristica("B", 5)
    g.add_heuristica("C", 10)
    g.add_heuristica("D", 8)
    g.add_heuristica("E", 30)
    g.add_heuristica("F", 12)
    g.add_heuristica("G", 16)
    g.add_heuristica("H", 39)
    g.add_heuristica("I", 34)


    c1 = ClienteC("v")
    c2 = ClienteC("s")
    c3 = ClienteC("d")



    e1 = c1.hacerEntrega(1,8, 1, "B", 8)
    e2 = c2.hacerEntrega(2,3, 2, "H", 2)
    e3 = c3.hacerEntrega(3,2, 3, "G", 3)
    e4 = c3.hacerEntrega(4,3, 3, "I", 4)
    e5 = c3.hacerEntrega(5,30, 3, "E", 5)


    gEntrega = Grafo()
    gEntrega.add_edge(e1.direccion_entrega,e2.direccion_entrega,1)
    gEntrega.add_edge(e2.direccion_entrega, e3.direccion_entrega, 1)
    gEntrega.add_edge(e3.direccion_entrega, e4.direccion_entrega, 1)
    gEntrega.add_edge(e4.direccion_entrega, e5.direccion_entrega, 1)
    gEntrega.add_edge(e5.direccion_entrega, e1.direccion_entrega, 1)


    entregas = []
    entregas.append(e1)
    entregas.append(e2)
    entregas.append(e3)
    entregas.append(e4)
    entregas.append(e5)

    m1 = MensajeroC(1, Bicicleta(),1)
    m2 = MensajeroC(2, Moto(),2)
    m3 = MensajeroC(3, Coche(),3)

    mensajeros = []
    mensajeros.append(m1)
    mensajeros.append(m2)
    mensajeros.append(m3)

    problema = Sostenibilidad(g, mensajeros, entregas, entregas)
    problema.asignarEntregas()

    saida = -1

    print("1-Imprimir Grafo")
    print("2-Desenhar ciudad")
    print("3-Disenhar entregas en grafo")
    print("4-BFS")
    print("5-Greedy")
    print("6-Camino mas corto")
    print("7-A*")
    print("0-Saír")

    saida = int(input("introduza a sua opcao-> "))
    if saida == 0:
        print("saindo.......")
    elif saida == 1:
        print(g.m_graph)
        l = input("prima enter para continuar")
    elif saida == 2:
        g.desenha()
    elif saida == 3:
        gEntrega.desenha()
    elif saida == 4:
        print(problema.realizarEntregasBFS())
        l = input("prima enter para continuar")
    elif saida == 5:
        print(problema.realizarEntregasGreedy())
        l = input("prima enter para continuar")
    elif saida == 6:
        print(problema.realizarEntregasdijkstra())
        l = input("prima enter para continuar")
    elif saida == 7:
        print(problema.realizarEntregasA_estrella())
    else:
        print("you didn't add anything")






if __name__ == "__main__":
    main()