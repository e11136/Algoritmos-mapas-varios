


class MensajeroC:

    def __init__(self, id_mensajero, transporte, parroquia):
        self.id_mensajero = id_mensajero
        self.transporte = transporte
        self.parroquia = parroquia
        self.estado = 'A'
        self.entregas_asignadas = []
        self.valor = []
        self.pesoTotal = 0
        self.tiempoTotal = 0


    def mostrarEstado(self):
        return self.estado

    def cambiarEstado(self,nodo):
        self.estado = nodo

    def realizar_entrega(self,entrega):
        # Lógica para realizar la entrega, actualizando el estado del mensajero
        self.pesoTotal = self.pesoTotal - entrega.pedido.peso
        self.entregas_asignadas.remove(entrega)
        self.valor.append(entrega.valoracion_cliente)
        pass
    def getEntregasAsignadas(self):
        return self.entregas_asignadas

    def getTransporte(self):
        return self.transporte

    def sumaPeso(self, peso):
        self.pesoTotal += peso

    def asignarEntrega(self, entrega):
        self.entregas_asignadas.append(entrega)

    def velocidad(self):
        return self.transporte.velocidad_media - (self.transporte.factor_reduccion_velocidad * self.pesoTotal)

    def aumentaTiempo(self, tiempo):
        self.tiempoTotal = self.tiempoTotal + tiempo
