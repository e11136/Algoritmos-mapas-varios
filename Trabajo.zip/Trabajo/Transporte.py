



class transporte:
    def __init__(self, tipo, velocidad_media, peso_maximo, rec,limDist):
        self.tipo = tipo
        self.velocidad_media = velocidad_media
        self.peso_maximo = peso_maximo
        self.factor_reduccion_velocidad = rec
        self.limDist = limDist


        # Definición de subclases que heredan de la superclase
class Bicicleta(transporte):
    def __init__(self):
                # Llamada al constructor de la superclase
        super().__init__("Bicicleta", velocidad_media=10, peso_maximo=5, rec = 0.6, limDist = 10)


class Moto(transporte):
    def __init__(self):
        super().__init__("Motocicleta", velocidad_media=35, peso_maximo=20, rec = 0.5,limDist = 35)



class Coche(transporte):
    def __init__(self):
        super().__init__("Automóvil", velocidad_media=50, peso_maximo=100, rec = 0.1, limDist= 70)

