from Pedido import PedidoC


class entrega:
    def __init__(self, pedido, direccionentrega, tiempo_max):
        self.pedido = pedido
        self.direccion_entrega = direccionentrega
        self.tiempo_maximo_entrega = tiempo_max
        self.valoracion_cliente = 0



    def getdireccion(self):
        return self.direccion_entrega

    def setValoracion(self, valoracion):
        # Lógica para valorar la entrega por parte del cliente
        self.valoracion_cliente = valoracion

    def getValoracion(self):
        return self.valoracion_cliente

    def calcular_precio(self, plazo_entrega, medio_transporte):
        # Supongamos que el precio base es de $5
        precio_base = 5

        # Ajustar el precio según el plazo de entrega
        precio_plazo = 0.5 * plazo_entrega  # Ejemplo: $0.50 por cada día de retraso

        # Ajustar el precio según el medio de transporte
        precio_transporte = 0
        if medio_transporte == "Bicicleta":
            precio_transporte = 2
        elif medio_transporte == "Motocicleta":
            precio_transporte = 5
        elif medio_transporte == "Automóvil":
            precio_transporte = 10

        # Calcular el precio total
        precio_total = precio_base + precio_plazo + precio_transporte
        return precio_total

'''# Ejemplo de uso
entrega1 = Entrega(1, "Calle X, Parroquia Y" , 2)
plazo_entrega = 1  # Ejemplo: el cliente quería la entrega en 1 día
medio_transporte = "Bicicleta"  # Ejemplo: entrega realizada en bicicleta

precio_entrega = entrega1.calcular_precio(plazo_entrega, medio_transporte)
print(f"Precio de la entrega: ${precio_entrega}")

# Ejemplo de uso
pedidop = PedidoC(peso = 5, vol= 20)
entrega1 = Entrega(pedido =pedidop , direccion_entrega="Calle X, Parroquia Y", tiempo_max=2)
print(entrega1)  # Output: Entrega 1: Calle X, Parroquia Y, Peso: 3, Tiempo Máximo: 2

# Cliente valora la entrega
entrega1.setValoracion(5)
print(entrega1.valoracion_cliente)  # Output: 5\/
'''

